# ICTspam
spamer dari joy_id
